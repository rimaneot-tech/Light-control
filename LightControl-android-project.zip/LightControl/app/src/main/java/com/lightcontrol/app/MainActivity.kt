package com.lightcontrol.app

import android.app.Activity
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import kotlin.math.cos

class MainActivity : Activity() {
    private lateinit var cm: CameraManager
    private var camId: String? = null
    @Volatile private var running = false
    @Volatile private var mode = 0
    @Volatile private var hz = 3.0
    private var worker: Thread? = null
    private val names = listOf("Мигающий", "Резкий", "Плавный", "Долгое мигание", "Свой режим")
    private val btns = ArrayList<Button>()
    private lateinit var power: Button
    private val gold = Color.parseColor("#FFD54A")

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        camId = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK)
            setPadding((20 * dp).toInt(), (48 * dp).toInt(), (20 * dp).toInt(), (24 * dp).toInt())
        }
        root.addView(TextView(this).apply {
            text = "🔦 Light Control"; textSize = 26f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; setPadding(0, 0, 0, (24 * dp).toInt())
        })
        power = Button(this).apply {
            text = "Включить"; textSize = 20f; setBackgroundColor(gold); setTextColor(Color.BLACK)
            setOnClickListener { if (running) stop() else start() }
        }
        root.addView(power, LinearLayout.LayoutParams(-1, (72 * dp).toInt()).apply { bottomMargin = (16 * dp).toInt() })
        names.forEachIndexed { i, n ->
            val b = Button(this).apply { text = n; setTextColor(Color.WHITE); setOnClickListener { select(i) } }
            btns.add(b)
            root.addView(b, LinearLayout.LayoutParams(-1, (56 * dp).toInt()).apply { bottomMargin = (8 * dp).toInt() })
        }
        val label = TextView(this).apply { text = "Скорость: 3.0 вспышек/с"; setTextColor(Color.LTGRAY); setPadding(0, (12 * dp).toInt(), 0, 0) }
        val bar = SeekBar(this).apply {
            max = 198; progress = 28
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                    hz = 0.2 + p / 10.0; label.text = "Скорость: %.1f вспышек/с".format(hz)
                    if (u) select(4)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(label); root.addView(bar)
        setContentView(root)
        select(0)
        if (camId == null) Toast.makeText(this, "Вспышка не найдена", Toast.LENGTH_LONG).show()
    }

    private fun select(i: Int) {
        mode = i
        btns.forEachIndexed { k, b -> b.setBackgroundColor(if (k == i) Color.parseColor("#4A3F10") else Color.parseColor("#1A1A1A")) }
    }

    private fun level(t: Long): Double = when (mode) {
        0 -> if (t % 1000 < 500) 1.0 else 0.0
        1 -> if (t % 83 < 30) 1.0 else 0.0
        2 -> (1 - cos(2 * Math.PI * (t % 3000) / 3000)) / 2
        3 -> if (t % 3000 < 1500) 1.0 else 0.0
        else -> { val p = 1000 / hz; if (t % p < p / 2) 1.0 else 0.0 }
    }

    private fun torch(on: Boolean) { try { camId?.let { cm.setTorchMode(it, on) } } catch (_: Exception) {} }

    private fun start() {
        if (camId == null) return
        running = true; power.text = "Выключить"; power.setBackgroundColor(Color.DKGRAY); power.setTextColor(Color.WHITE)
        worker = Thread {
            val t0 = System.nanoTime(); var last = false
            while (running) {
                val t = (System.nanoTime() - t0) / 1_000_000
                val l = level(t)
                val on = if (mode == 2) (t % 60) / 60.0 < l else l >= 0.5
                if (on != last) { torch(on); last = on }
                try { Thread.sleep(4) } catch (_: InterruptedException) {}
            }
            torch(false)
        }.also { it.start() }
    }

    private fun stop() {
        running = false; worker?.join(300)
        power.text = "Включить"; power.setBackgroundColor(gold); power.setTextColor(Color.BLACK)
    }

    override fun onPause() { super.onPause(); if (running) stop() }
}
